Stacks adds a new `s-prose` class that you can slap on any block of vanilla HTML content and turn it into a beautiful, well-formatted document:

```html
<article class="s-prose">
  <h1>Garlic bread with cheese: What the science tells us</h1>
  <p>
    For years parents have espoused the health benefits of eating garlic bread with cheese to their
    children, with the food earning such an iconic status in our culture that kids will often dress
    up as warm, cheesy loaf for Halloween.
  </p>
  <p>
    But a recent study shows that the celebrated appetizer may be linked to a series of rabies cases
    springing up around the country.
  </p>
  <!-- ... -->
</article>
```

## What to expect from here on out

What follows from here is just a bunch of absolute nonsense we’ve written to dogfood the component itself. It includes every sensible typographic element we could think of, like **bold text**, unordered lists, ordered lists, code blocks, block quotes, _and even italics_.

It’s important to cover all of these use cases for a few reasons:

1. We want everything to look good out of the box.
2. Really just the first reason, that’s the whole point of the plugin.
3. Here’s a third pretend reason though a list with three items looks more realistic than a list with two items.

Now we’re going to try out another header style.

### Typography should be easy

So that’s a header for you—with any luck if we’ve done our job correctly that will look pretty reasonable.

Something a wise person once told me about typography is:

> Typography is pretty important if you don’t want your stuff to look like trash. Make it good then it won’t be bad.

It’s probably important that images look okay here by default as well:

<img
  src="https://images.unsplash.com/photo-1556740758-90de374c12ad?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1000&q=80"
  alt=""
/>

Now I’m going to show you an example of an unordered list to make sure that looks good, too:

- So here is the first item in this list.
- In this example we’re keeping the items short.
- Later, we’ll use longer, more complex list items.

And that’s the end of this section.

## What if we stack headings?

### We should make sure that looks good, too.

Sometimes you have headings directly underneath each other. In those cases you often have to undo the top margin on the second heading because it usually looks better for the headings to be closer together than a paragraph followed by a heading should be.

### When a heading comes after a paragraph …

When a heading comes after a paragraph, we need a bit more space, like I already mentioned above. Now let’s see what a more complex list would look like.

- **I often do this thing where list items have headings.**

  For some reason I think this looks cool which is unfortunate because it’s pretty annoying to get the styles right.

  I often have two or three paragraphs in these list items, too, so the hard part is getting the spacing between the paragraphs, list item heading, and separate list items to all make sense. Pretty tough honestly, you could make a strong argument that you just shouldn’t write this way.

- **Since this is a list, I need at least two items.**

  I explained what I’m doing already in the previous list item, but a list wouldn’t be a list if it only had one item, and we really want this to look realistic. That’s why I’ve added this second list item so I actually have something to look at when writing the styles.

- **It’s not a bad idea to add a third item either.**

  I think it probably would’ve been fine to just use two items but three is definitely not worse, and since I seem to be having no trouble making up arbitrary things to type, I might as well include it.

After this sort of list I usually have a closing statement or paragraph, because it kinda looks weird jumping right to a heading.

## Code should look okay by default.

Here’s what a default `tailwind.config.js` file looks like at the time of writing:

```js
module.exports = {
  purge: [],
  theme: {
    extend: {},
  },
  variants: {},
  plugins: [],
}
```

Hopefully that looks good enough to you.

### What about nested lists?

Nested lists basically always look bad which is why editors like Medium don’t even let you do it, but I guess since some of you goofballs are going to do it we have to carry the burden of at least making it work.

1. **Nested lists are rarely a good idea.**
   - You might feel like you are being really “organized” or something but you are just creating a gross shape on the screen that is hard to read.
   - Nested navigation in UIs is a bad idea too, keep things as flat as possible.
   - Nesting tons of folders in your source code is also not helpful.
2. **Since we need to have more items, here’s another one.**
   - I’m not sure if we’ll bother styling more than two levels deep.
   - Two is already too much, three is guaranteed to be a bad idea.
   - If you nest four levels deep you belong in prison.
3. **Two items isn’t really a list, three is good though.**
   - Again please don’t nest lists if you want people to actually read your content.
   - Nobody wants to look at this.
   - I’m upset that we even have to bother styling this.

The most annoying thing about lists in Markdown is that `<li>` elements aren’t given a child `<p>` tag unless there are multiple paragraphs in the list item. That means I have to worry about styling that annoying situation too.

- **For example, here’s another nested list.**

  But this time with a second paragraph.

  - These list items won’t have `<p>` tags
  - Because they are only one line each

- **But in this second top-level list item, they will.**

  This is especially annoying because of the spacing on this paragraph.

  - As you can see here, because I’ve added a second line, this list item now has a `<p>` tag.

    This is the second line I’m talking about by the way.

  - Finally here’s another list item so it’s more like a list.

- A closing list item, but with no nested list, because why not?

And finally a sentence to close off this section.

## There are other elements we need to style

I almost forgot to mention links, like [Stack Overflow](https://stackoverflow.com).

We even included table styles, check it out:

<div class="s-table-container">
  <table class="s-table">
    <thead>
      <tr>
        <th>Wrestler</th>
        <th>Origin</th>
        <th>Finisher</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Bret "The Hitman" Hart</td>
        <td>Calgary, AB</td>
        <td>Sharpshooter</td>
      </tr>
      <tr>
        <td>Stone Cold Steve Austin</td>
        <td>Austin, TX</td>
        <td>Stone Cold Stunner</td>
      </tr>
      <tr>
        <td>Randy Savage</td>
        <td>Sarasota, FL</td>
        <td>Elbow Drop</td>
      </tr>
      <tr>
        <td>Vader</td>
        <td>Boulder, CO</td>
        <td>Vader Bomb</td>
      </tr>
      <tr>
        <td>Razor Ramon</td>
        <td>Chuluota, FL</td>
        <td>Razor’s Edge</td>
      </tr>
    </tbody>
  </table>
</div>

We also need to make sure inline code looks good, like if I wanted to talk about `<span>` elements.

### Sometimes I even use `code` in headings

Another thing I’ve done in the past is put a `code` tag inside of a link, like if I wanted to tell you about the [`stackexchange/stacks`](https://github.com/stackexchange/stacks) repository.

### We still need to think about stacked headings though.

#### Let’s make sure we don’t screw that up with `h4` elements, either.

Phew, with any luck we have styled the headings above this text and they look pretty good.

##### We should also make sure we're styling `h5` elements as well.

Let’s add a closing paragraph here so things end with a decently sized block of text. I can’t explain why I want things to end that way but I have to assume it’s because I think things will look weird or unbalanced if there is a heading too close to the end of the document.

###### And, finally, an `h6`.
Ultimately, though, we also want to support the `h6` headers.

What I’ve written here is probably long enough, but adding this final sentence can’t hurt.