// allows stimulus to be used as a UMD global from TypeScript.
// You can delete this file after https://github.com/stimulusjs/stimulus/issues/238 has been fixed
export * from "stimulus";
export as namespace Stimulus;
