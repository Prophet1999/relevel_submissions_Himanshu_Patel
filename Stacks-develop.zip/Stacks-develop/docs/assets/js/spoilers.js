$(document).ready(function() {
    $(".js-spoiler").click(function(e) {
        $(this).addClass("is-visible");
    });
});
